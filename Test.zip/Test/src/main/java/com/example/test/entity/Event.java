package com.example.test.entity;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Arrays;

public class Event {
    private Integer eid;
    private String title;
    private String details;
    private Timestamp start;
    private Timestamp end;
    private String image; // path
    private Integer hid;
    private BigDecimal price1;
    private BigDecimal price2;
    private BigDecimal price3;
    private BigDecimal turnover;
    private byte[] imageData; // actual image binary data

    public Event() {
    }

    public Integer getEid() {
        return eid;
    }

    public void setEid(Integer eid) {
        this.eid = eid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public Timestamp getStart() {
        return start;
    }

    public void setStart(Timestamp start) {
        this.start = start;
    }

    public Timestamp getEnd() {
        return end;
    }

    public void setEnd(Timestamp end) {
        this.end = end;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Integer getHid() {
        return hid;
    }

    public void setHid(Integer hid) {
        this.hid = hid;
    }

    public BigDecimal getPrice1() {
        return price1;
    }

    public void setPrice1(BigDecimal price1) {
        this.price1 = price1;
    }

    public BigDecimal getPrice2() {
        return price2;
    }

    public void setPrice2(BigDecimal price2) {
        this.price2 = price2;
    }

    public BigDecimal getPrice3() {
        return price3;
    }

    public void setPrice3(BigDecimal price3) {
        this.price3 = price3;
    }

    public BigDecimal getTurnover() {
        return turnover;
    }

    public void setTurnover(BigDecimal turnover) {
        this.turnover = turnover;
    }

    public byte[] getImageData() {
        return imageData;
    }

    public void setImageData(byte[] imageData) {
        this.imageData = imageData;
    }

    @Override
    public String toString() {
        return "Event{" +
                "eid=" + eid +
                ", title='" + title + '\'' +
                ", details='" + details + '\'' +
                ", start=" + start +
                ", end=" + end +
                ", image='" + image + '\'' +
                ", hid=" + hid +
                ", price1=" + price1 +
                ", price2=" + price2 +
                ", price3=" + price3 +
                ", turnover=" + turnover +
                ", imageData=" + Arrays.toString(imageData) +
                '}';
    }
}
