package com.example.test;

import com.example.test.state.Client;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;

public class Customer{
    @FXML
    private StackPane contentArea;
    @FXML
    private Button logout;

    @FXML
    private Label userEmail;


    public void customerEvents(ActionEvent event) throws IOException {
        setUserEmailLabel();
        Parent scene = FXMLLoader.load(getClass().getResource("events.fxml"));
        contentArea.getChildren().removeAll();
        contentArea.getChildren().setAll(scene);
    }

    public void myTickets(ActionEvent event) throws IOException {
        setUserEmailLabel();
        Parent scene = FXMLLoader.load(getClass().getResource("my-tickets.fxml"));
        contentArea.getChildren().removeAll();
        contentArea.getChildren().setAll(scene);
    }

    public void logout(ActionEvent event) throws IOException {
        Client.logout();
        Parent scene = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) logout.getScene().getWindow();
        window.setScene(new Scene(scene,1133,744));
    }

    private void setUserEmailLabel(){
        userEmail.setText(Client.currentUser.getEmail());
    }
}
