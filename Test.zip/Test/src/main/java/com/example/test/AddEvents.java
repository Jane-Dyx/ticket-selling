package com.example.test;


import com.example.test.entity.Message;
import com.example.test.utils.APICaller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import com.jfoenix.controls.JFXTextArea;


public class AddEvents  {
    @FXML
    private Button confirm;

    @FXML
    private AnchorPane informationPane;

    @FXML
    private TextField titleTextField;

    @FXML
    private JFXTextArea detailsField;

    @FXML
    private DatePicker datePicker;

    @FXML
    private TextField timeField;

    @FXML
    private RadioButton hall1Btn, hall2Btn;

    @FXML
    private  TextField price1Field, price2Field,price3Field;

    private String title, details, date, time, hall, price1, price2, price3;


    @FXML
    public void confirmOnAction(ActionEvent event) throws IOException {
        if(checkInput()){
            // parse date and send requests
            Message msg = APICaller.createEvent(
                    title,
                    details,
                    date + " " + time + ":00",
                    null,
                    hall,
                    price1,
                    price2,
                    price3,
                    null,
                    null
            );
            if(msg.getCode() == Message.CORRECT_CODE){
                Parent scene = FXMLLoader.load(getClass().getResource("admin.fxml"));
                Stage window = (Stage) confirm.getScene().getWindow();
                window.setScene(new Scene(scene,1133,744));
            }else{
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Something went wrong, please try later.");
                alert.show();
            }
        }else{
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("PLease make sure all fields are properly filled.");
            alert.show();
        }
    }

    public void informationOnClicked(ActionEvent event) {
        informationPane.setVisible(true);
    }

    public void exitOnAction(ActionEvent event){
        informationPane.setVisible(false);
    }

    private boolean checkInput(){
        title = titleTextField.getText();
        details  = detailsField.getText();
        if(datePicker.getValue() != null){
            date = datePicker.getValue().toString();
        }
        time = timeField.getText();
        if(hall1Btn.isSelected()){
            hall = "1";
        }else if(hall2Btn.isSelected()){
            hall = "2";
        }
        price1 = price1Field.getText();
        price2 = price2Field.getText();
        price3 = price3Field.getText();
        if(title != null && !title.isEmpty()
                && details != null && !details.isEmpty()
                && date != null && !date.isEmpty()
                && time != null && !time.isEmpty()
                && hall != null && !hall.isEmpty()
                && price1 != null && !price1.isEmpty()
                && price2 != null && !price2.isEmpty()
                && price3 != null && !price3.isEmpty()
        ){
            return true;
        }else{
            return false;
        }
    }

}
