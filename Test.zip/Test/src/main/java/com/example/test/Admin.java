package com.example.test;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;

public class Admin {
    @FXML
    private StackPane contentArea;
    @FXML
    private Button logout;

    public void events(ActionEvent event) throws IOException {
        Parent scene = FXMLLoader.load(getClass().getResource("events.fxml"));
        contentArea.getChildren().removeAll();
        contentArea.getChildren().setAll(scene);
    }

    public void addEvents(ActionEvent event) throws IOException {
        Parent scene = FXMLLoader.load(getClass().getResource("addEvents.fxml"));
        contentArea.getChildren().removeAll();
        contentArea.getChildren().setAll(scene);
    }

    public void logout(ActionEvent event) throws IOException {
        Parent scene = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) logout.getScene().getWindow();
        window.setScene(new Scene(scene,1133,744));
    }
}
