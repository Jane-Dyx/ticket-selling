package com.example.test;

import com.example.test.state.Client;
import com.example.test.utils.APICaller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class Login {
    @FXML
    private Button login;
    @FXML
    private Button signup,pwd;

    @FXML
    private TextField emailTextField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private void loginButtonOnAction(ActionEvent event) throws IOException {
        String email = emailTextField.getText();
        String pwd = passwordField.getText();
        Client.currentUser = APICaller.login(email, pwd);
        if(Client.currentUser.getUid() != -1){
            Parent scene;
            if(Client.currentUser.getRole().equals("admin")){
                scene = FXMLLoader.load(getClass().getResource("admin.fxml"));
            }else{
                scene = FXMLLoader.load(getClass().getResource("customer.fxml"));
            }
            Stage window = (Stage) login.getScene().getWindow();
            window.setScene(new Scene(scene,1133,744));
        }else{
            emailTextField.clear();
            passwordField.clear();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Wrong email or password!");
            alert.show();
        }
    }

    @FXML
    private void signUpOnAction(ActionEvent event) throws IOException {
        Parent scene = FXMLLoader.load(getClass().getResource("sign-up.fxml"));
        Stage window = (Stage) signup.getScene().getWindow();
        window.setScene(new Scene(scene,1133,744));
    }

    @FXML
    private void changePwdOnAction(ActionEvent event) throws IOException {
        Parent scene = FXMLLoader.load(getClass().getResource("password.fxml"));
        Stage window = (Stage) pwd.getScene().getWindow();
        window.setScene(new Scene(scene,1133,744));
    }
}
