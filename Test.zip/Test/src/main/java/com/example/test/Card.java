package com.example.test;

import com.example.test.entity.Event;
import com.example.test.entity.Ticket;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

public class Card {
    private Event event;

    @FXML
    private Label hall;

    @FXML
    private ImageView image;

    @FXML
    private Label time;

    @FXML
    private Label title;

    @FXML
    private VBox vbox;
    public void setData(Event event) {
        this.event = event;
        title.setText(event.getTitle());
        hall.setText("Hall " + event.getHid());
        // TODO: image wtf
        String t = event.getStart().toString();
        time.setText(t.substring(0, t.length() - 2));
    }

    public Event getEvent() {
        return event;
    }

}
