package com.example.test.entity;

public class Hall {
    private Integer hid;
    private String name;
    private Integer capacity;
    private Integer zone1;
    private Integer zone2;
    private Integer zone3;

    public Hall() {
    }

    public Integer getHid() {
        return hid;
    }

    public void setHid(Integer hid) {
        this.hid = hid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Integer getZone1() {
        return zone1;
    }

    public void setZone1(Integer zone1) {
        this.zone1 = zone1;
    }

    public Integer getZone2() {
        return zone2;
    }

    public void setZone2(Integer zone2) {
        this.zone2 = zone2;
    }

    public Integer getZone3() {
        return zone3;
    }

    public void setZone3(Integer zone3) {
        this.zone3 = zone3;
    }

    @Override
    public String toString() {
        return "Hall{" +
                "hid=" + hid +
                ", name='" + name + '\'' +
                ", capacity=" + capacity +
                ", zone1=" + zone1 +
                ", zone2=" + zone2 +
                ", zone3=" + zone3 +
                '}';
    }
}
