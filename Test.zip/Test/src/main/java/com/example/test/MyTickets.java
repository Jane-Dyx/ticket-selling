package com.example.test;

import com.example.test.entity.Ticket;
import com.example.test.state.Client;
import com.example.test.utils.APICaller;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class MyTickets implements Initializable {
    private List<Ticket> tickets;
    @FXML
    private GridPane gridPane;

    @Override
    public void initialize(URL location, ResourceBundle resourceBundle){
        tickets = APICaller.getUserTickets(Client.currentUser.getUid());
        int columns = 0;
        int rows = 0;

        try{
            for(int i = 0; i < tickets.size(); i++){
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("tickets.fxml"));
                AnchorPane vbox = fxmlLoader.load();
                Tickets card = fxmlLoader.getController();

                card.setData(tickets.get(i));

                if(columns == 2){
                    columns = 0;
                    ++rows;
                }

                gridPane.add(vbox, columns++, rows);
                gridPane.setHgap(20); //horizontal gap in pixels => that's what you are asking for
                gridPane.setVgap(20); //vertical gap in pixels
                gridPane.setPadding(new Insets(20, 20, 20, 20));

            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
