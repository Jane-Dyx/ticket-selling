package com.example.test;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class Password {
    @FXML
    private Button confirm, back;

    @FXML
    public void confirmButtonOnAction(ActionEvent event) throws IOException {
        Parent scene = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) confirm.getScene().getWindow();
        window.setScene(new Scene(scene,1133,744));
    }

    public void cancelButtonOnAction(ActionEvent event) throws IOException {
        Parent scene = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) confirm.getScene().getWindow();
        window.setScene(new Scene(scene,1133,744));
    }

}
