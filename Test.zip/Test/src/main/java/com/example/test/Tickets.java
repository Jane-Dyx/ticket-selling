package com.example.test;

import com.example.test.entity.Event;
import com.example.test.entity.Ticket;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class Tickets {
    @FXML
    private Label hall;

    @FXML
    private Label price;

    @FXML
    private Label seatNo;

    @FXML
    private Label time;

    @FXML
    private Label title;

    @FXML
    private VBox vbox;

    public void setData(Ticket ticket) {
        title.setText(ticket.getEvent().getTitle());
        seatNo.setText("Seat No " + ticket.getSeatNo().toString());
        hall.setText("Hall " + ticket.getEvent().getHid());
        String t = ticket.getEvent().getStart().toString();
        time.setText(t.substring(0, t.length() - 2));
        price.setText("RM " + ticket.getPrice());
        // TODO: set all attributes
    }

}
