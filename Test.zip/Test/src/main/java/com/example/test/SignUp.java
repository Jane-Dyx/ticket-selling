package com.example.test;

import com.example.test.state.Client;
import com.example.test.utils.APICaller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class SignUp {
    @FXML
    private Button signup;
    @FXML
    private Button login;

    @FXML
    private TextField emailTextField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private void signUpButtonOnAction(ActionEvent event) throws IOException {
        String email = emailTextField.getText();
        String pwd = passwordField.getText();
        Client.currentUser = APICaller.signUp(email, pwd);
        if(Client.currentUser.getUid() != -1){
            // TODO: redirect to login page
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("You've successfully created your account!");
            alert.show();
            Parent scene = FXMLLoader.load(getClass().getResource("login.fxml"));
            Stage window = (Stage) signup.getScene().getWindow();
            window.setScene(new Scene(scene,1133,744));
        } else{
            // TODO: failed to login
            emailTextField.clear();
            passwordField.clear();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Email existed!");
            alert.show();
        }
    }

    @FXML
    private void loginJFXButton(ActionEvent event) throws IOException {
        Parent scene = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) login.getScene().getWindow();
        window.setScene(new Scene(scene,1133,744));
    }

}
