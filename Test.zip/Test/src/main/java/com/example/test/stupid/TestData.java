package com.example.test.stupid;

import com.example.test.entity.Event;
import com.example.test.entity.Ticket;

import java.util.ArrayList;
import java.util.List;

public class TestData {
    public static List<Event> someEvents(){
        ArrayList<Event> events = new ArrayList<>();
        for(int i = 0;i < 8;i++){
            Event event = new Event();
            event.setEid(i);
            event.setTitle("Event" + i);
            events.add(event);
        }
        return events;
    }

    public static List<Ticket> someTickets(){
        ArrayList<Ticket> tickets = new ArrayList<>();
        for(int i = 0;i < 8;i++){
            Ticket ticket  = new Ticket();
            ticket.setSeatNo(i);
            tickets.add(ticket);
        }
        return tickets;
    }
}
