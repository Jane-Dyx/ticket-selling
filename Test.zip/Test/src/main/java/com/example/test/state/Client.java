package com.example.test.state;

import com.example.test.entity.Event;
import com.example.test.entity.User;

public class Client {
    public static User currentUser = null;
    public static Event selectedEvent = null;

    public static Integer selectedSeatNo = null;

    public static void logout(){
        Client.currentUser = null;
        Client.selectedEvent = null;
        Client.selectedSeatNo = 0;
    }
}
