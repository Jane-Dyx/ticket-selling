package com.example.test;

import com.example.test.entity.Event;
import com.example.test.state.Client;
import com.example.test.utils.APICaller;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class Events implements Initializable {
    private List<Event> events;
    @FXML
    private GridPane gridPane;

    @Override
    public void initialize(URL location, ResourceBundle resourceBundle){
        events = APICaller.getAllEvents();
        int columns = 0;
        int rows = 0;

        try{
            for(int i = 0; i < events.size(); i++){
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("card.fxml"));
                AnchorPane vbox = fxmlLoader.load();
                Card card = fxmlLoader.getController();

                card.setData(events.get(i));

                if(columns == 2){
                    columns = 0;
                    ++rows;
                }


                vbox.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        if(Client.currentUser.getRole().equals("admin")){
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setContentText("Turnover: RM " + card.getEvent().getTurnover());
                            alert.show();
                        }else{
                            Client.selectedEvent = card.getEvent();
                            jumpToHallView(Client.selectedEvent.getHid());
                        }
                    }
                });

                gridPane.add(vbox, columns++, rows);
                gridPane.setHgap(20); //horizontal gap in pixels => that's what you are asking for
                gridPane.setVgap(20); //vertical gap in pixels
                gridPane.setPadding(new Insets(20, 20, 20, 20));

            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void jumpToHallView(Integer hid){
        if(hid == 1){
            Parent scene = null;
            try {
                scene = FXMLLoader.load(getClass().getResource("hall.fxml"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Stage window = (Stage) gridPane.getScene().getWindow();
            window.setScene(new Scene(scene,1133,744));
        }else{
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("Hall 2 not done yet.");
            alert.show();
        }
    }

}
