package com.example.test;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Hall1 implements Initializable {

    @FXML
    private GridPane gridPane;
    @FXML
    private Button confirm;

    @FXML
    public void confirmOnAction(ActionEvent event) throws IOException {
        Parent scene = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) confirm.getScene().getWindow();
        window.setScene(new Scene(scene,1133,744));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            for(int row = 0;row < 9;row++){
                for(int col = 0;col < 7;col++){
                    FXMLLoader fxmlLoader = new FXMLLoader();
                    fxmlLoader.setLocation(getClass().getResource("seat-button.fxml"));

                    AnchorPane seatView = fxmlLoader.load();
                    SeatButton seatController = fxmlLoader.getController();


                    gridPane.add(seatView, col, row);
                    gridPane.setPadding(new Insets(5));
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}

