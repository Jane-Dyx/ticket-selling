package com.example.test;

import com.example.test.entity.Event;
import com.example.test.entity.Message;
import com.example.test.entity.Ticket;
import com.example.test.state.Client;
import com.example.test.utils.APICaller;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Hall implements Initializable {
    @FXML
    private StackPane contentArea;
    @FXML
    private Button logout;
    @FXML
    private GridPane gridPane;
    @FXML
    private Button confirm;

    @FXML
    private Label titleLabel;

    @FXML
    private Label timeLabel;

    @FXML
    private Label hallLabel;

    @FXML
    private Label zone1;

    @FXML
    private Label zone2;

    @FXML
    private Label zone3;

    @FXML
    private Label userEmail;

    @FXML
    public void confirmOnAction(ActionEvent event) throws IOException {
        setUserEmailLabel();
        if(Client.selectedSeatNo <= 0){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setContentText("You haven't chosen any seats!");
            alert.show();
        }else{
            Message msg = APICaller.bookTicket(Client.selectedEvent.getEid(), Client.currentUser.getUid(), Client.selectedSeatNo);
            if(msg.getCode() == Message.CORRECT_CODE){
                Parent scene = FXMLLoader.load(getClass().getResource("success.fxml"));
                Stage window = (Stage) confirm.getScene().getWindow();
                window.setScene(new Scene(scene,1133,744));
            }else{
                // TODO: refresh the seat view
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setContentText("Sorry, somebody booked the ticket just now, please choose another one.");
                alert.show();
            }
        }
    }
    public void myTickets(ActionEvent event) throws IOException {
        setUserEmailLabel();
        Parent scene = FXMLLoader.load(getClass().getResource("my-tickets.fxml"));
        contentArea.getChildren().removeAll();
        contentArea.getChildren().setAll(scene);
    }
    public void customerEvents(ActionEvent event) throws IOException {
        setUserEmailLabel();
        Parent scene = FXMLLoader.load(getClass().getResource("events.fxml"));
        contentArea.getChildren().removeAll();
        contentArea.getChildren().setAll(scene);
    }

    public void logout(ActionEvent event) throws IOException {
        Client.logout();
        Parent scene = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window = (Stage) logout.getScene().getWindow();
        window.setScene(new Scene(scene,1133,744));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        setUserEmailLabel();
        Client.selectedSeatNo = 0; // clear it

        Event e = Client.selectedEvent;

        List<Ticket> seats = APICaller.getEventSeats(e.getEid());

        titleLabel.setText(e.getTitle());
        String t = e.getStart().toString();
        timeLabel.setText("Time: " + t.substring(0, t.length() - 2));
        hallLabel.setText("Venue: Hall " + e.getHid());
        zone1.setText("RM" + e.getPrice1().toString());
        zone2.setText("RM" + e.getPrice2().toString());
        zone3.setText("RM" + e.getPrice3().toString());

        List<SeatButton> seatBtns = new ArrayList<>();

        try {
            for(int row = 0;row < 9;row++){
                for(int col = 0;col < 7;col++){
                    FXMLLoader fxmlLoader = new FXMLLoader();
                    fxmlLoader.setLocation(getClass().getResource("seat-button.fxml"));

                    AnchorPane seatView = fxmlLoader.load();
                    SeatButton seatController = fxmlLoader.getController();

                    seatBtns.add(seatController);

                    Integer sno = row * 7 + col + 1;
                    seatController.setData(sno, seats.get(sno - 1).getUid());

                    seatView.setOnMouseClicked(
                            new EventHandler<MouseEvent>() {
                                @Override
                                public void handle(MouseEvent mouseEvent) {
                                    if(seats.get(sno - 1).getUid() > 0){
                                        // the seat is sold already... do nothing
                                    }else{
                                        if(Client.selectedSeatNo == sno){
                                            // already choose it, unselect it
                                            seatController.unchooseSeat();
                                            Client.selectedSeatNo = 0;

                                        }else{
                                            // select the seat
                                            if(Client.selectedSeatNo > 0){
                                                seatBtns.get(Client.selectedSeatNo - 1).unchooseSeat();
                                            }
                                            seatController.chooseSeat();
                                            Client.selectedSeatNo = sno;
                                        }
                                    }
                                }
                            }
                    );

                    gridPane.add(seatView, col, row);
                    gridPane.setPadding(new Insets(5));
                }
            }

        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }

    }

    private void setUserEmailLabel(){
        userEmail.setText(Client.currentUser.getEmail());
    }

}
