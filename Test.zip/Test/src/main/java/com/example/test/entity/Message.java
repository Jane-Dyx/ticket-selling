package com.example.test.entity;

public class Message {
    public static final int ERROR_CODE = 0;
    public static final int CORRECT_CODE = 1;

    private int code;
    private String message;

    public Message() {
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "Message{" +
                "code=" + code +
                ", message='" + message + '\'' +
                '}';
    }
}
