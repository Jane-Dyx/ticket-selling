package com.example.test.utils;

import com.example.test.entity.Event;
import com.example.test.entity.Message;
import com.example.test.entity.Ticket;
import com.example.test.entity.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.squareup.okhttp.*;



import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class APICaller {
//    private static final String BASE_URL = "https://127.0.0.1:7777";
private static final String BASE_URL = "https://169.254.31.128:7777";
    private static Gson gson = new GsonBuilder().create();

    public static User login(String email, String password){
        OkHttpClient client = new OkHttpClient();
        client.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                //TODO: Make this more restrictive
                return true;
            }
        });

        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\n  \"email\": \"" + email + "\",\n  \"password\": \""+password + "\"\n}\n");
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/auth/login")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
        }
        User result = null;
        try {
            result = gson.fromJson(response.body().string(), User.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static User signUp(String email, String password){
        OkHttpClient client = new OkHttpClient();
        client.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                //TODO: Make this more restrictive
                return true;
            }
        });
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody body = RequestBody.create(mediaType, "{\n  \"email\": \"" + email + "\",\n  \"password\": \""+password + "\"\n}\n");
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/auth/signup")
                .method("POST", body)
                .addHeader("Content-Type", "application/json")
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
        }
        User result = null;
        try {
            result = gson.fromJson(response.body().string(), User.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static Message createEvent(
            String title,
            String details,
            String start,
            String end,
            String hid,
            String price1,
            String price2,
            String price3,
            String filename,
            String filepath
    ){
        OkHttpClient client = new OkHttpClient();
        client.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                //TODO: Make this more restrictive
                return true;
            }
        });
//        RequestBody body = new MultipartBuilder().type(MultipartBuilder.FORM)
//                .addFormDataPart("title","Testing")
//                .addFormDataPart("details","This is event details.")
//                .addFormDataPart("start","2023-06-15 20:00:00")
//                .addFormDataPart("end","2023-06-15 22:00:00")
//                .addFormDataPart("hid","2")
//                .addFormDataPart("price1","1.00")
//                .addFormDataPart("price2","2.00")
//                .addFormDataPart("price3","30.00")
//                .addFormDataPart("image","charity.png",
//                        RequestBody.create(MediaType.parse("application/octet-stream"),
//                                new File("/Users/xiongkouqin/Downloads/charity.png")))
//                .build();
        RequestBody body = new MultipartBuilder().type(MultipartBuilder.FORM)
                .addFormDataPart("title",title)
                .addFormDataPart("details",details)
                .addFormDataPart("start",start)
                .addFormDataPart("hid",hid)
                .addFormDataPart("price1",price1)
                .addFormDataPart("price2",price2)
                .addFormDataPart("price3",price3)
                .build();
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/event")
                .method("POST", body)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Message result = null;
        try {
            result = gson.fromJson(response.body().string(), Message.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static List<Event> getAllEvents(){
        OkHttpClient client = new OkHttpClient();
        client.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                //TODO: Make this more restrictive
                return true;
            }
        });
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/event")
                .method("GET", null)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Type listType = new TypeToken<ArrayList<Event>>(){}.getType();
        List<Event> result = null;
        try {
            result = gson.fromJson(response.body().string(), listType);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static List<Ticket> getEventSeats(Integer eid){
        OkHttpClient client = new OkHttpClient();
        client.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                //TODO: Make this more restrictive
                return true;
            }
        });
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/event/" + eid)
                .method("GET", null)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Type listType = new TypeToken<ArrayList<Ticket>>(){}.getType();
        List<Ticket> result = null;
        try {
            result = gson.fromJson(response.body().string(), listType);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static Message bookTicket(
            Integer eid,
            Integer uid,
            Integer seatNo
    ){
        OkHttpClient client = new OkHttpClient();
        client.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                //TODO: Make this more restrictive
                return true;
            }
        });

        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/event/" + eid + "/" + uid + "/" + seatNo)
                .method("POST", body)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Message result = null;
        try {
            result = gson.fromJson(response.body().string(), Message.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static List<Ticket> getUserTickets(Integer uid){
        OkHttpClient client = new OkHttpClient();
        client.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                //TODO: Make this more restrictive
                return true;
            }
        });
        Request request = new Request.Builder()
                .url(BASE_URL + "/api/ticket/" + uid)
                .method("GET", null)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Type listType = new TypeToken<ArrayList<Ticket>>(){}.getType();
        List<Ticket> result = null;
        try {
            result = gson.fromJson(response.body().string(), listType);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }


    public static void main(String[] args) {
        System.out.println(login("admin@ticket.com","123456"));
//        System.out.println(signUp("admin@ticket.com","123456"));
//        System.out.println(createEvent());
        // TODO: check the arguments usage
//        System.out.println(getAllEvents());
//        System.out.println(getEventSeats(2));
//        System.out.println(getUserTickets(1));
//        System.out.println(bookTicket(1,1,7));
    }
}
