package com.example.test.entity;

import java.math.BigDecimal;

public class Ticket {
    private Integer tid;
    private Integer eid;
    private Integer seatNo;
    private Integer uid; // if uid == 0 means the ticket is not sold yet
    private BigDecimal price;

    private Event event; // make it simple when see user's tickets, he can also see other information

    public Ticket() {
    }

    public Integer getTid() {
        return tid;
    }

    public void setTid(Integer tid) {
        this.tid = tid;
    }

    public Integer getEid() {
        return eid;
    }

    public void setEid(Integer eid) {
        this.eid = eid;
    }

    public Integer getSeatNo() {
        return seatNo;
    }

    public void setSeatNo(Integer seatNo) {
        this.seatNo = seatNo;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "tid=" + tid +
                ", eid=" + eid +
                ", seatNo=" + seatNo +
                ", uid=" + uid +
                ", price=" + price +
                ", event=" + event +
                '}';
    }
}
