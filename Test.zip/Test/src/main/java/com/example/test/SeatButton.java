package com.example.test;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Ellipse;

public class SeatButton {
    public final static Color SOLD_COLOR = Color.web("#747474");
    public final static Color CHOOSEN_COLOR = Color.web("#acb1d6");
    public final static Color AVAI_COLOR = Color.web("#ffffff");

    @FXML
    private Ellipse seatNoBG;

    @FXML
    private Label seatNoLabel;

    public void setData(Integer seatNo, Integer uid){
        seatNoLabel.setText(seatNo.toString());

        if(uid < 1){
            seatNoBG.setFill(AVAI_COLOR);
        }else{
            seatNoBG.setFill(SOLD_COLOR);
        }
    }

    public void chooseSeat(){
        seatNoBG.setFill(CHOOSEN_COLOR);
    }

    public void unchooseSeat(){
        seatNoBG.setFill(AVAI_COLOR);
    }
}
